import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose'
import { SingupModel } from './signup.model';
import { Model } from 'mongoose';
interface User{
    username:string,
    email:string,
    password:string
}
@Injectable()
export class SignupService {
    constructor(@InjectModel('Signup') private SignupModel: Model<SingupModel>) { }
    async signup(user:User){
        const newUser=new this.SignupModel({
            username:user.username,
            email:user.email,
            password:user.password
        })
        try{
            await newUser.save()
        }
        catch(e){
            console.log(e)
        }
    }
}
