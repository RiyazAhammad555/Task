import { Body, Controller, Post } from '@nestjs/common';
import { SignupService } from './signup.service';
import { SignupDto } from './signup.dto';

@Controller('signup') //http://localhost:8000/signup 
export class SignupController {
    constructor(private readonly SignupService: SignupService) { }
    @Post()
    signup(@Body() SignupDto: SignupDto) {
        return this.SignupService.signup(SignupDto)
    }
}

